﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

#pragma warning disable CA1814

namespace HouseRentingSystem.Data.Migrations
{
    public partial class InitialCreate : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_Houses_Agents_AgentId",
                table: "Houses");

            migrationBuilder.DropTable(
                name: "Agents");

            migrationBuilder.AlterColumn<string>(
                name: "AgentId",
                table: "Houses",
                type: "nvarchar(450)",
                nullable: false,
                oldClrType: typeof(int),
                oldType: "int");

            migrationBuilder.UpdateData(
                table: "Categories",
                keyColumn: "Id",
                keyValue: 1,
                column: "Name",
                value: "Cottage");

            migrationBuilder.UpdateData(
                table: "Categories",
                keyColumn: "Id",
                keyValue: 2,
                column: "Name",
                value: "Single-Family house");

            migrationBuilder.InsertData(
                table: "Categories",
                columns: new[] { "Id", "Name" },
                values: new object[,]
                {
                    { 3, "Duplex" },
                    { 4, "One Bedroom" },
                    { 5, "Two Bedroom" }
                });

            migrationBuilder.InsertData(
                table: "AspNetUsers",
                columns: new[]
                {
                    "Id",
                    "UserName",
                    "NormalizedUserName",
                    "Email",
                    "NormalizedEmail",
                    "EmailConfirmed",
                    "PasswordHash",
                    "SecurityStamp",
                    "ConcurrencyStamp",
                    "PhoneNumberConfirmed",
                    "TwoFactorEnabled",
                    "LockoutEnabled",
                    "AccessFailedCount"
                },
                values: new object[]
                {
                    "13d2281e-1912-45f4-8aef-9c1288ac7fbc",
                    "agent@test.com",
                    "AGENT@TEST.COM",
                    "agent@test.com",
                    "AGENT@TEST.COM",
                    true,
                    null,
                    "13d2281e-1912-45f4-8aef-9c1288ac7fbc",
                    "13d2281e-1912-45f4-8aef-9c1288ac7fbc",
                    false,
                    false,
                    true,
                    0
                });

            migrationBuilder.InsertData(
                table: "Houses",
                columns: new[]
                {
                    "Id",
                    "Address",
                    "AgentId",
                    "CategoryId",
                    "Description",
                    "ImageUrl",
                    "PricePerMonth",
                    "RenterId",
                    "Title"
                },
                values: new object[,]
                {
                    {
                        1,
                        "North London, UK (near the border)",
                        "13d2281e-1912-45f4-8aef-9c1288ac7fbc",
                        2,
                        "A big house for your whole family. Don't miss to buy a house with three bedrooms.",
                        "https://www.luxury-architecture.net/wp-content/uploads/2017/12/1513217889-7597-FAIRWAYS-010.jpg",
                        2100.00m,
                        null,
                        "Big House Marina"
                    },
                    {
                        2,
                        "Near the Sea Garden in Burgas, Bulgaria",
                        "13d2281e-1912-45f4-8aef-9c1288ac7fbc",
                        2,
                        "It has the best comfort you will ever ask for. With two bedrooms, it is great for your family.",
                        "https://cf.bstatic.com/xdata/images/hotel/max1024x768/179489660.jp?k=2029f6d9589b49c95dcc9503a265e292c2cdfcb5277487a0050397c3f8dd545a&o=&hp=1",
                        1200.00m,
                        null,
                        "Family House Comfort"
                    }
                });

            migrationBuilder.AddForeignKey(
                name: "FK_Houses_AspNetUsers_AgentId",
                table: "Houses",
                column: "AgentId",
                principalTable: "AspNetUsers",
                principalColumn: "Id",
                onDelete: ReferentialAction.Restrict);
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_Houses_AspNetUsers_AgentId",
                table: "Houses");

            migrationBuilder.DeleteData(
                table: "Houses",
                keyColumn: "Id",
                keyValue: 1);

            migrationBuilder.DeleteData(
                table: "Houses",
                keyColumn: "Id",
                keyValue: 2);

            migrationBuilder.DeleteData(
                table: "AspNetUsers",
                keyColumn: "Id",
                keyValue: "13d2281e-1912-45f4-8aef-9c1288ac7fbc");

            migrationBuilder.DeleteData(
                table: "Categories",
                keyColumn: "Id",
                keyValue: 3);

            migrationBuilder.DeleteData(
                table: "Categories",
                keyColumn: "Id",
                keyValue: 4);

            migrationBuilder.DeleteData(
                table: "Categories",
                keyColumn: "Id",
                keyValue: 5);

            migrationBuilder.AlterColumn<int>(
                name: "AgentId",
                table: "Houses",
                type: "int",
                nullable: false,
                oldClrType: typeof(string),
                oldType: "nvarchar(450)");

            migrationBuilder.CreateTable(
                name: "Agents",
                columns: table => new
                {
                    Id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    UserId = table.Column<string>(type: "nvarchar(450)", nullable: false),
                    PhoneNumber = table.Column<string>(type: "nvarchar(15)", maxLength: 15, nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Agents", x => x.Id);

                    table.ForeignKey(
                        name: "FK_Agents_AspNetUsers_UserId",
                        column: x => x.UserId,
                        principalTable: "AspNetUsers",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.UpdateData(
                table: "Categories",
                keyColumn: "Id",
                keyValue: 1,
                column: "Name",
                value: "Urban");

            migrationBuilder.UpdateData(
                table: "Categories",
                keyColumn: "Id",
                keyValue: 2,
                column: "Name",
                value: "Suburban");

            migrationBuilder.CreateIndex(
                name: "IX_Agents_UserId",
                table: "Agents",
                column: "UserId");

            migrationBuilder.AddForeignKey(
                name: "FK_Houses_Agents_AgentId",
                table: "Houses",
                column: "AgentId",
                principalTable: "Agents",
                principalColumn: "Id",
                onDelete: ReferentialAction.Cascade);
        }
    }
}