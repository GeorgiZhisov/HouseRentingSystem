﻿using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HouseRentingSystem.Data.Data.Entities.Configuration
{
    public class HouseConfiguration : IEntityTypeConfiguration<House>
    {
        public void Configure(EntityTypeBuilder<House> builder)
        {

            builder
                .HasOne(h => h.Category)
                .WithMany(c => c.Houses)
                .HasForeignKey(h => h.CategoryId)
                .OnDelete(DeleteBehavior.Restrict);
            builder
                .HasOne(h => h.Agent)
                .WithMany(a => a.Houses)
                .HasForeignKey(h => h.AgentId)
                .OnDelete(DeleteBehavior.Restrict);
            builder.HasData(SeedHouses());


        }

        private IEnumerable<House> SeedHouses()
        {
            return new House[]
            {
                new House() {
                    Id = 1,
                    Title = "Big House Marina",
                    Address = "North London, UK (near the border)",
                    Description = "A big house for your whole family. Don't miss to buy a house with three bedrooms.",
                    ImageUrl = "https://images.unsplash.com/photo-1568605114967-8130f3a36994",
                    PricePerMonth = 2100.00M,
                    CategoryId = 2,
                    AgentId = "13d2281e-1912-45f4-8aef-9c1288ac7fbc"
                },
                new House() {
                    Id = 2,
                    Title = "Family House Comfort",
                    Address = "Near the Sea Garden in Burgas, Bulgaria",
                    Description = "It has the best comfort you will ever ask for. With two bedrooms, it is great for your family.",
                    ImageUrl = "https://images.unsplash.com/photo-1505693416388-ac5ce068fe85",
                    PricePerMonth = 1200.00M,
                    CategoryId = 2,
                    AgentId = "13d2281e-1912-45f4-8aef-9c1288ac7fbc"
                }
            };
        }
    }
}
